package com.watermonitor.service;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

/**
 * 虚拟数据计算服务
 * 预计算所有管网的基础值，分析查询直接查表，O(1) 复杂度
 */
@Service
public class VirtualDataService {

    private static final int PIPE_COUNT = 500;
    private static final String[] PIPE_AREAS = {
        "城北", "城南", "城东", "城西", "高新", "经开", "滨江", "老城", "新城", "开发区",
        "朝阳", "海淀", "丰台", "石景山", "大兴", "通州", "顺义", "昌平", "房山", "密云"
    };
    private static final String[] PIPE_TYPES = {"供水主管", "供水支管", "排水主管", "排水支管", "雨水管", "污水管", "中水管", "消防管"};

    // 预计算表
    private final double[] pipeBaseFlow = new double[PIPE_COUNT + 1];      // 每管网基础流量
    private final double[] pipeBasePressure = new double[PIPE_COUNT + 1];  // 每管网基础水压
    private final double[][] pipeHourFlow = new double[PIPE_COUNT + 1][24]; // 每管网每小时的基准流量
    private final double[][] pipeHourPressure = new double[PIPE_COUNT + 1][24]; // 每管网每小时的基准水压
    private final double[] hourFactor = new double[24];                     // 小时因子
    private final String[] pipeNoCache = new String[PIPE_COUNT + 1];
    private final String[] pipeNameCache = new String[PIPE_COUNT + 1];

    @PostConstruct
    void init() {
        for (int h = 0; h < 24; h++) hourFactor[h] = computeHourFactor(h);
        for (int p = 1; p <= PIPE_COUNT; p++) {
            pipeBaseFlow[p] = 50 + (p % 50) * 10;
            pipeBasePressure[p] = 0.2 + ((p * 7) % 100) / 250.0;
            pipeNoCache[p] = "PIPE" + String.format("%04d", p);
            pipeNameCache[p] = PIPE_AREAS[p % PIPE_AREAS.length] + "-" + PIPE_TYPES[p % PIPE_TYPES.length] + "-" + p;
            // 管网类型决定用水节奏
            int pipeType = p % 8; // 8 种管网类型
            double personality = 0.85 + 0.3 * ((p * 17 + 13) % 100) / 100.0;
            for (int h = 0; h < 24; h++) {
                double hf = computeHourFactor(h, pipeType) * personality;
                pipeHourFlow[p][h] = pipeBaseFlow[p] * hf;
                pipeHourPressure[p][h] = pipeBasePressure[p] * (1.0 - (hf - 1.0) * 0.3);
            }
        }
    }

    // ====== 基础计算 ======

    private double computeHourFactor(int hour) {
        if (hour >= 6 && hour <= 9) return 1.8;
        if (hour >= 11 && hour <= 13) return 1.3;
        if (hour >= 17 && hour <= 21) return 1.9;
        if (hour >= 22 || hour <= 4) return 0.3;
        return 0.8;
    }

    private double seasonalFactor(int month) {
        if (month >= 6 && month <= 8) return 1.3;
        if (month == 12 || month <= 2) return 0.8;
        return 1.0;
    }

    private boolean isWeekend(LocalDate date) {
        return date.getDayOfWeek().getValue() >= 6;
    }

    /** 按管网类型调整小时因子偏移（供水/排水/雨水等不同节奏） */
    private double computeHourFactor(int hour, int pipeType) {
        // 0=供水,1=排水  → 标准早晚高峰
        // 2=雨水        → 没有明显高峰
        // 3=污水/中水/消防 → 偏夜间/均匀
        int shift = pipeType <= 1 ? 0 : (pipeType == 2 ? 2 : -2);
        int h = (hour + shift + 24) % 24;
        if (h >= 6 && h <= 9) return 1.8;
        if (h >= 11 && h <= 13) return 1.3;
        if (h >= 17 && h <= 21) return 1.9;
        if (h >= 22 || h <= 4) return 0.3;
        return 0.8;
    }

    /** 每日随机波动（±30%，让曲线不那么光滑） */
    private double dailyChaos(LocalDate date) {
        long seed = date.toEpochDay() * 0x9e3779b9L;
        seed = (seed ^ (seed >>> 30)) * 0xbf58476d1ce4e5b9L;
        seed = (seed ^ (seed >>> 27)) * 0x94d049bb133111ebL;
        seed = seed ^ (seed >>> 31);
        return 0.7 + ((seed & 0x7fffffffL) % 6000) / 10000.0;
    }

    /** 确定性噪音，用于单管网查询时引入变化 */
    private double noise(int pipeIndex, LocalDate date, int hour) {
        long seed = (long) pipeIndex * 1000000L + date.toEpochDay() * 100L + hour;
        seed = (seed ^ (seed >>> 33)) * 0x45d9f3bL;
        seed = (seed ^ (seed >>> 29)) * 0x9e3779b9L;
        seed = seed ^ (seed >>> 32);
        return 0.85 + ((seed & 0x7fffffffL) % 10000) / 10000.0 * 0.3;
    }

    private double round(double v) { return Math.round(v * 100.0) / 100.0; }

    // ====== 公开接口 ======

    /** 计算指定管网在指定日期小时的流量（用于单管网查询和预测） */
    public double getFlowRate(int pipeIndex, LocalDate date, int hour) {
        double weekendFactor = isWeekend(date) ? 0.75 : 1.0;
        double seasonal = seasonalFactor(date.getMonthValue());
        double chaos = dailyChaos(date);
        return pipeHourFlow[pipeIndex][hour] * weekendFactor * seasonal * chaos * noise(pipeIndex, date, hour);
    }

    // ====== 分析接口（利用预计算表，O(days) 复杂度） ======

    public Map<String, Object> flowTrend(String startDateStr, String endDateStr, String pipeNo) {
        LocalDate start = LocalDate.parse(startDateStr);
        LocalDate end = LocalDate.parse(endDateStr);

        List<String> dates = new ArrayList<>();
        List<Double> totalFlows = new ArrayList<>();
        List<Double> avgFlows = new ArrayList<>();

        if (pipeNo != null && !pipeNo.isEmpty()) {
            int p = Integer.parseInt(pipeNo.substring(4));
            LocalDate d = start;
            while (!d.isAfter(end)) {
                double sum = 0;
                double wf = isWeekend(d) ? 0.75 : 1.0;
                double sf = seasonalFactor(d.getMonthValue());
                double chaos = dailyChaos(d);
                for (int h = 0; h < 24; h++) {
                    sum += pipeHourFlow[p][h] * wf * sf * chaos * noise(p, d, h);
                }
                dates.add(d.toString());
                totalFlows.add(round(sum));
                avgFlows.add(round(sum / 24));
                d = d.plusDays(1);
            }
        } else {
            LocalDate d = start;
            while (!d.isAfter(end)) {
                double sum = 0;
                double wf = isWeekend(d) ? 0.75 : 1.0;
                double sf = seasonalFactor(d.getMonthValue());
                double chaos = dailyChaos(d);
                for (int p = 1; p <= PIPE_COUNT; p++) {
                    for (int h = 0; h < 24; h++) {
                        sum += pipeHourFlow[p][h] * wf * sf * chaos * noise(p, d, h);
                    }
                }
                dates.add(d.toString());
                totalFlows.add(round(sum));
                avgFlows.add(round(sum / (PIPE_COUNT * 24)));
                d = d.plusDays(1);
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("dates", dates);
        result.put("totalFlows", totalFlows);
        result.put("avgFlows", avgFlows);
        result.put("dataCount", dates.size());
        return result;
    }

    public Map<String, Object> anomalyStats(String startDateStr, String endDateStr) {
        LocalDate start = LocalDate.parse(startDateStr);
        LocalDate end = LocalDate.parse(endDateStr);

        int[] counts = new int[4];
        long total = 0;

        LocalDate d = start;
        while (!d.isAfter(end)) {
            double wf = isWeekend(d) ? 0.75 : 1.0;
            double sf = seasonalFactor(d.getMonthValue());
            double chaos = dailyChaos(d);
            for (int p = 1; p <= PIPE_COUNT; p++) {
                for (int h = 0; h < 24; h++) {
                    double flow = pipeHourFlow[p][h] * wf * sf * chaos * noise(p, d, h);
                    double pressure = pipeHourPressure[p][h] * wf * sf * chaos * noise(p, d, h + 100);
                    double flowDev = Math.abs(flow - pipeBaseFlow[p]) / pipeBaseFlow[p];
                    double pressDev = Math.abs(pressure - pipeBasePressure[p]) / pipeBasePressure[p];
                    if (flowDev > 1.5 || pressDev > 0.6) counts[3]++;
                    else if (flowDev > 1.0 || pressDev > 0.4) counts[2]++;
                    else if (flowDev > 0.5 || pressDev > 0.2) counts[1]++;
                    else counts[0]++;
                    total++;
                }
            }
            d = d.plusDays(1);
        }

        String[] labels = {"正常", "轻微异常", "中度异常", "严重异常"};
        List<String> labelList = new ArrayList<>();
        List<Double> valueList = new ArrayList<>();
        List<Map<String, Object>> detail = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            double pct = total > 0 ? round(counts[i] * 100.0 / total) : 0;
            labelList.add(labels[i]);
            valueList.add(pct);
            Map<String, Object> d2 = new LinkedHashMap<>();
            d2.put("anomalyLevel", i);
            d2.put("count", counts[i]);
            d2.put("percentage", pct);
            detail.add(d2);
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("labels", labelList);
        result.put("values", valueList);
        result.put("detail", detail);
        return result;
    }

    public Map<String, Object> weekdayWeekendCompare(String startDateStr, String endDateStr) {
        LocalDate start = LocalDate.parse(startDateStr);
        LocalDate end = LocalDate.parse(endDateStr);

        double weekdaySum = 0, weekendSum = 0;
        int weekdayCount = 0, weekendCount = 0;

        LocalDate d = start;
        while (!d.isAfter(end)) {
            double wf = isWeekend(d) ? 0.75 : 1.0;
            double sf = seasonalFactor(d.getMonthValue());
            double chaos = dailyChaos(d);
            for (int p = 1; p <= PIPE_COUNT; p++) {
                for (int h = 0; h < 24; h++) {
                    double flow = pipeHourFlow[p][h] * wf * sf * chaos;
                    if (isWeekend(d)) { weekendSum += flow; weekendCount++; }
                    else { weekdaySum += flow; weekdayCount++; }
                }
            }
            d = d.plusDays(1);
        }

        Map<String, Object> result = new LinkedHashMap<>();
        Map<String, Object> wd = new LinkedHashMap<>();
        wd.put("dayType", "工作日");
        wd.put("totalFlow", round(weekdaySum));
        wd.put("avgFlow", round(weekdayCount > 0 ? weekdaySum / weekdayCount : 0));
        Map<String, Object> we = new LinkedHashMap<>();
        we.put("dayType", "周末");
        we.put("totalFlow", round(weekendSum));
        we.put("avgFlow", round(weekendCount > 0 ? weekendSum / weekendCount : 0));
        result.put("data", Arrays.asList(wd, we));
        result.put("工作日", wd.get("avgFlow"));
        result.put("周末", we.get("avgFlow"));
        return result;
    }

    public Map<String, Object> peakHourAnalysis(String startDateStr, String endDateStr) {
        LocalDate start = LocalDate.parse(startDateStr);
        LocalDate end = LocalDate.parse(endDateStr);

        double[] hourSums = new double[24];
        double[] hourMaxs = new double[24];
        int[] hourCounts = new int[24];

        LocalDate d = start;
        while (!d.isAfter(end)) {
            double wf = isWeekend(d) ? 0.75 : 1.0;
            double sf = seasonalFactor(d.getMonthValue());
            double chaos = dailyChaos(d);
            for (int p = 1; p <= PIPE_COUNT; p++) {
                for (int h = 0; h < 24; h++) {
                    double flow = pipeHourFlow[p][h] * wf * sf * chaos;
                    hourSums[h] += flow;
                    if (flow > hourMaxs[h]) hourMaxs[h] = flow;
                    hourCounts[h]++;
                }
            }
            d = d.plusDays(1);
        }

        List<Integer> hours = new ArrayList<>();
        List<Double> avgFlows = new ArrayList<>();
        List<Double> maxFlows = new ArrayList<>();
        int peakHour = 0;
        double peakAvg = 0;

        for (int h = 0; h < 24; h++) {
            double avg = hourCounts[h] > 0 ? hourSums[h] / hourCounts[h] : 0;
            hours.add(h);
            avgFlows.add(round(avg));
            maxFlows.add(round(hourMaxs[h]));
            if (avg > peakAvg) { peakAvg = avg; peakHour = h; }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("hours", hours);
        result.put("avgFlows", avgFlows);
        result.put("maxFlows", maxFlows);
        result.put("peakHour", peakHour);
        return result;
    }

    public Map<String, Object> multiPipeCompare(String startDateStr, String endDateStr, int topN) {
        LocalDate start = LocalDate.parse(startDateStr);
        LocalDate end = LocalDate.parse(endDateStr);

        double[] pipeTotals = new double[PIPE_COUNT + 1];
        int[] pipeRecords = new int[PIPE_COUNT + 1];

        LocalDate d = start;
        while (!d.isAfter(end)) {
            double wf = isWeekend(d) ? 0.75 : 1.0;
            double sf = seasonalFactor(d.getMonthValue());
            double chaos = dailyChaos(d);
            for (int p = 1; p <= PIPE_COUNT; p++) {
                double daySum = 0;
                for (int h = 0; h < 24; h++) {
                    daySum += pipeHourFlow[p][h] * wf * sf * chaos;
                }
                pipeTotals[p] += daySum;
                pipeRecords[p] += 24;
            }
            d = d.plusDays(1);
        }

        List<Integer> indexes = new ArrayList<>();
        for (int p = 1; p <= PIPE_COUNT; p++) indexes.add(p);
        indexes.sort((a, b) -> Double.compare(pipeTotals[b], pipeTotals[a]));
        if (indexes.size() > topN) indexes = indexes.subList(0, topN);

        List<String> names = new ArrayList<>();
        List<Double> totalFlows = new ArrayList<>();
        List<Double> avgFlows = new ArrayList<>();
        for (int p : indexes) {
            names.add(pipeNameCache[p]);
            totalFlows.add(round(pipeTotals[p]));
            avgFlows.add(round(pipeRecords[p] > 0 ? pipeTotals[p] / pipeRecords[p] : 0));
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("names", names);
        result.put("totalFlows", totalFlows);
        result.put("avgFlows", avgFlows);
        return result;
    }

    public List<String> getAllPipeNos() {
        List<String> list = new ArrayList<>();
        for (int i = 1; i <= PIPE_COUNT; i++) list.add(pipeNoCache[i]);
        return list;
    }

    public int getPipeCount() { return PIPE_COUNT; }
}
